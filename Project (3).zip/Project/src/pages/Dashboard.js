import React from 'react';
import AppointmentList from '../components/AppointmentList';

const Dashboard = () => {
    return (
        <div>
            <h1>Admin Dashboard</h1>
            <p>Welcome to the admin panel. Here you can view and manage all appointments.</p>
            <AppointmentList />
        </div>
    );
};

export default Dashboard;