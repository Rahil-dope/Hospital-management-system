import axios from 'axios';

const API_URL = 'http://localhost:5000/api/appointments';

export const getAllAppointments = async () => {
    try {
        const response = await axios.get(API_URL);
        return response.data;
    } catch (error) {
        throw new Error('Error fetching appointments: ' + error.message);
    }
};

export const getAppointmentDetails = async (id) => {
    try {
        const response = await axios.get(`${API_URL}/${id}`);
        return response.data;
    } catch (error) {
        throw new Error('Error fetching appointment details: ' + error.message);
    }
};