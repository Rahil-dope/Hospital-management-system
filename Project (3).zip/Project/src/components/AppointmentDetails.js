import React from 'react';

const AppointmentDetails = ({ appointment }) => {
    if (!appointment) {
        return <div>No appointment selected.</div>;
    }

    return (
        <div className="appointment-details">
            <h2>Appointment Details</h2>
            <p><strong>Patient Name:</strong> {appointment.patientName}</p>
            <p><strong>Doctor:</strong> {appointment.doctor}</p>
            <p><strong>Date:</strong> {new Date(appointment.date).toLocaleDateString()}</p>
            <p><strong>Time:</strong> {new Date(appointment.date).toLocaleTimeString()}</p>
            <p><strong>Department:</strong> {appointment.department}</p>
            <p><strong>Additional Information:</strong> {appointment.message || 'N/A'}</p>
        </div>
    );
};

export default AppointmentDetails;