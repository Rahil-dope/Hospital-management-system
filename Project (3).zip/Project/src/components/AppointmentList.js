import React, { useEffect, useState } from 'react';
import { fetchAppointments } from '../services/api';

const AppointmentList = () => {
    const [appointments, setAppointments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const getAppointments = async () => {
            try {
                const data = await fetchAppointments();
                setAppointments(data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        getAppointments();
    }, []);

    if (loading) {
        return <div>Loading appointments...</div>;
    }

    if (error) {
        return <div>Error fetching appointments: {error}</div>;
    }

    return (
        <div>
            <h2>Appointment List</h2>
            <ul>
                {appointments.map(appointment => (
                    <li key={appointment.id}>
                        {appointment.date} - {appointment.patientName}
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default AppointmentList;